#CONFIGURE
$Servers = 'n31-exch.cyberdyne.corp'
$CM_ID_MAILBOX = 'CM_220307090350'
$CM_ID_QUEUE = 'CM_220307090432'
$CM_ID_REPLICATION = 'CM_220307090510'
$GMCDestFile = '/data1/riverbed/NetIM/op_admin/tmp/vne/generic_metrics/input/'
$Frequency = 300    
$ExchangeUserName = 'skynet\Administrator'
$ExchangePassword = 'myeLab!'
$NetIMCoreServer = '10.99.31.75'
$NetIMUser = 'netimadmin'
$NetIMPassword = 'netimadmin'
#$NetIMGMCFolder = '/data1/riverbed/NetIM/op_admin/tmp/vne/generic_metrics/input/'
#CONFIGURE

#[int]$iter=1

#while(1)
{
$pwdSecureString = ConvertTo-SecureString -Force -AsPlainText $ExchangePassword
$UserCredential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $ExchangeUserName, $pwdSecureString

$MTRContentsMailbox = @()
$MTRContentsMailbox += '[SampleDataHeader][name=MAILBOX][metricClass='+$CM_ID_MAILBOX+']timestamp,MailboxDisplayName,MessageTableTotalSize,MessageTableAvailableSize'
$MTRContentsMailbox += '[TargetInfoHeader]HEADERNAME,SYSNAME'
$MTRContentsQueue = @()
$MTRContentsQueue += '[SampleDataHeader][name=QUEUE][metricClass='+$CM_ID_QUEUE+']timestamp,MailboxDBName,Status,CopyQueueLength,ReplayQueueLength,ContentIndexState'
$MTRContentsQueue += '[TargetInfoHeader]HEADERNAME,SYSNAME'
$MTRContentsReplication = @()
$MTRContentsReplication += '[SampleDataHeader][name=REPLICATION][metricClass='+$CM_ID_REPLICATION+']timestamp,Check,Result'
$MTRContentsReplication += '[TargetInfoHeader]HEADERNAME,SYSNAME'

foreach ($Server in $Servers)
    {	
    #Set-ExecutionPolicy Unrestricted
    $Session = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri http://$Server/PowerShell/ -Authentication Negotiate -Credential $UserCredential
    Import-PSSession $Session -AllowClobber

    $reportMailbox = @()			
    Get-MailboxStatistics -server $Server | `
    Group-Object -Property MailboxGuid | %{
    $row = ""| select DisplayName,MessageTableTotalSize,MessageTableAvailableSize
    [string]$row.DisplayName = $_.Group[0].DisplayName
    [string]$row.MessageTableTotalSize = $_.Group.MessageTableTotalSize.Value
    [string]$row.MessageTableAvailableSize = $_.Group.MessageTableAvailableSize.Value
    $reportMailbox += $row
    }

    $reportQueue = @()			
    Get-MailboxDatabaseCopyStatus | `
    Group-Object -Property DatabaseName| %{
    $row = ""| select DatabaseName,Status,CopyQueueLength,ReplayQueuelength,ContentIndexState
    [string]$row.DatabaseName = $_.Group.DatabaseName
    [string]$row.Status = $_.Group.Status
    [string]$row.CopyQueueLength = $_.Group[0].CopyQueueLength
    [string]$row.ReplayQueuelength = $_.Group[0].ReplayQueuelength
    [string]$row.ContentIndexState = $_.Group[0].ContentIndexState
    $reportQueue += $row
    }

    $reportReplication = @()			
    Test-ReplicationHealth  | `
    Group-Object -Property Check | %{
    $row = ""| select Check,Result
    [string]$row.Check = $_.Group[0].Check
    [string] $row.Result = $_.Group[0].Result
    $reportReplication += $row
    }
    #Remove-PSSession $Session
    }


$epochModifier = 0
cls

foreach ($mailbox in $reportMailbox)
    {
    $DisplayName = $mailbox.DisplayName
    $MessageTableTotalSize = $mailbox.MessageTableTotalSize
    $SplitA1 = $MessageTableTotalSize.split('(')[1]
    $SplitA2 = $SplitA1.split(')')[0]
    $SplitA3 = $SplitA2.split(' ')[0]
    $trimA = $SplitA3.replace(',','')
    $MessageTableAvailableSize = $mailbox.MessageTableAvailableSize
    $SplitB1 = $MessageTableAvailableSize.split('(')[1]
    $SplitB2 = $SplitB1.split(')')[0]
    $SplitB3 = $SplitB2.split(' ')[0]
    $trimB = $SplitB3.replace(',','')

    $datetimeepoch=[Math]::Floor([decimal](Get-Date(Get-Date).ToUniversalTime()-uformat "%s"))
    $datetimeepoch=$datetimeepoch*1000 
    $datetimeepochModified=$datetimeepoch + $epochModifier

    $MTRContentsMailbox += '[TI]MAILBOX,'+ $Server +'[SI][SD]'+ $datetimeepochModified +','+ $DisplayName +','+ $trimA +','+ $trimB
    $destfilenameMailbox =$GMCDestFile+'Mailbox'+$datetimeepoch+'.mtr';
    $MTRContentsMailbox | Out-File $destfilenameMailbox -Encoding ascii
    $epochModifier = $epochModifier + 1
    }



foreach ($queue in $reportQueue)
    {
    $DatabaseName = $queue.DatabaseName
    $Status = $queue.Status
    if($Status -eq 'Mounted')
    {$StatusBinary = 1}
    else
    {$StatusBinary = 0}
    $CopyQueueLength = $queue.CopyQueueLength
    $ReplayQueuelength =$queue.ReplayQueuelength
    $ContentIndexState = $queue.ContentIndexState
    if($ContentIndexState -eq 'Healthy')
    {$ContentIndexStateBinary = 1}
    else
    {$ContentIndexStateBinary = 0}

    $datetimeepoch=[Math]::Floor([decimal](Get-Date(Get-Date).ToUniversalTime()-uformat "%s"))
    $datetimeepoch=$datetimeepoch*1000 
    $datetimeepochModified=$datetimeepoch + $epochModifier
             
    $MTRContentsQueue += '[TI]QUEUE,'+ $Server +'[SI][SD]'+ $datetimeepochModified +','+$DatabaseName +','+ $StatusBinary +','+ $CopyQueueLength +','+$ReplayQueuelength +','+  $ContentIndexStateBinary
    $destfilenameQueue =$GMCDestFile+'Queue'+$datetimeepoch+'.mtr';
    $MTRContentsQueue | Out-File $destfilenameQueue -Encoding ascii
    $epochModifier = $epochModifier + 1
    }



foreach ($replication in $reportReplication)
    {
    $Check = $replication.Check
    $Result = $replication.Result
    if($Result -eq 'Passed')
    {$ResultBinary = 1}
    else
    {$ResultBinary = 0}
    $datetimeepoch=[Math]::Floor([decimal](Get-Date(Get-Date).ToUniversalTime()-uformat "%s"))
    $datetimeepoch=$datetimeepoch*1000 
    $datetimeepochModified=$datetimeepoch + $epochModifier
             
    $MTRContentsReplication += '[TI]REPLICATION,'+ $Server +'[SI][SD]'+ $datetimeepochModified +','+ $Check +','+ $ResultBinary
    $destfilenameReplication =$GMCDestFile+'Replication'+$datetimeepoch+'.mtr';
    $MTRContentsReplication | Out-File $destfilenameReplication -Encoding ascii
    $epochModifier = $epochModifier + 1
    }


Write-Host 'Completed' #$iter

#$iter=$iter+1

$PSCPString = '-batch -scp -pw' +' '+ $NetIMPassword + ' ' + $GMCDestFile +'*.mtr ' + $NetIMUser + '@' + $NetIMCoreServer + ':' + $NetIMGMCFolder
#$RemoveItemString = $GMCDestFile + '*.*'
Start-Process $Pscp -ArgumentList ($PSCPString)
#Start-Sleep -Seconds $Frequency
#Remove-Item $RemoveItemString
}
